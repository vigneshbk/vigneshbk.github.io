

Kafka 
 - Messaging 
 - Horizontal scaling/Distributed
 - Ordered

- Central Hub of Distributed processing
- Distributed Event Ledger  = Distributed Commit Log - append only
- Linear Clustering perfomance - increase 
- Has Messaging Scemantics
- Core is clustering
- Durability and Ordering garauntee

Key Terms
Records -> 
(K,V,Timestamp), immutable, Persisted and Appendonly to Ledger
Broker ->

Producer ->

Consumer ->
