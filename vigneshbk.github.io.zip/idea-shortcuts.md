class:remark-slide-vig
layout:true
---
 
.header[Intellij Idea shortcuts for Eclipse Dev]
 
   1. **New File**
   2. **Find in File** --> Ctrl + F
   3. **Search Everywhere** --> Double Shift  
   4. **Find Replace**
   5. ** Go to Previous Edit** Ctl + Shift + Backspace

   6. **Find Implementing Classes**
      CTRL + ALT + B  : To find all implementations of a given class.
   7. **Formatting code**
   8. **Surround With blocks**
   9. Generate code : getter/s#etters
   10. ads
   11.
---

page 2

Ref : https://www.jetbrains.com/help/idea/2017.1/keyboard-shortcuts-you-cannot-miss.html
